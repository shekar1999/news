#include <stdio.h>

void sleep (int s)
{
	printf("I am not sleeping!\n");
}
